package com.nguyenvietquan.rest_api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.transaction.annotation.Transactional;

import com.nguyenvietquan.rest_api.model.Users;


@Configuration 
// Annotation này có tác dụng báo với Spring Container Context là, hảy tạo bean cho lớp UserServiceMongoImpl,
// và trong lớp MainRestController , chúng ta @Autowired để dùng UserServiceMongoImpl
@Transactional
public class UserServiceMongoImpl implements UserService{
	
	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Users findById(long id) {
// nếu không thấy return null
		return mongoTemplate.findById(id, Users.class);
	}

	@Override
	public Users findByName(String name) {
		return null;
	}
	
	
//	 create User
	@Override
	public void saveUsers(Users users) {
//   Nếu chưa có collection, Mongo tự tạo collection với tên là Users
		mongoTemplate.save(users);
		
	}

	@Override
	public void updateUsers(Users users) {
//		query to search user
		Query searchUserQuery = new Query(Criteria.where("id").is(users.getId()));
		
//		 find the user just query
		Users savedUser = mongoTemplate.findOne(searchUserQuery, Users.class);
		System.out.println("find savedUser "+ savedUser);
		if((users.getName()!=null)){
			savedUser.setName(users.getName());
		}
		if(users.getAge()!=0){
			savedUser.setAge(users.getAge());
		}
        if(users.getSalary()!=0){
        	savedUser.setSalary(users.getSalary());
        }
		mongoTemplate.save(savedUser);
//		 update field name
//		 cách này chỉ update được có 1 field ah
//		mongoTemplate.updateFirst(searchUserQuery, Update.update("name",users.getName()), Users.class);
		
		Users updatedUser = mongoTemplate.findOne(searchUserQuery, Users.class);
		System.out.println("find savedUser "+ updatedUser);
		
	}

//	delete user by id
	@Override
	public void deleteUsersById(long id) {
		Users user = findById(id);
		mongoTemplate.remove(user);
	}

//	delete all of the users
	@Override
	public void deleteAllUsers() {
		Query searchUserQuery = new Query();
		mongoTemplate.remove(searchUserQuery,"Users");
//		mongoTemplate.dropCollection(Users.class); xóa cả collection 
//		mongoTemplate.dropCollection("Users");   xóa cả collection
	}

//	Kiễm tra xem Users có tồn tại không
	@Override
	public boolean isUsersExist(Users users) {
		Users user = findById(users.getId());
		if(user==null){
			return false;
		}
		return true;
	}

//	Xem  tất cả users trong collection
	@Override
	public List<Users> findAllUsers() {
		return mongoTemplate.findAll(Users.class);
		
	}

}
