package com.nguyenvietquan.rest_api.service;

import java.util.List;

import com.nguyenvietquan.rest_api.model.Users;

public interface UserService {
	
	Users findById(long id);
	Users findByName(String name);
	void saveUsers(Users users);
	void updateUsers(Users users);
	void deleteUsersById(long id);
	void deleteAllUsers();
	boolean isUsersExist(Users users);
	List<Users> findAllUsers();

}
