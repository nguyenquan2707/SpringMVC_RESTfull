package com.kscodes.sampleproject.config;

import java.net.UnknownHostException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;

@Configuration// Annotation này có tác dụng, thông báo với container trong lớp này có 1 @Bean là MongoTemplate
@EnableMongoRepositories(basePackages = "com.kscodes.sampleproject.config")
public class SpringMongoConfig {
	
	// thông tin để connect MongoDb
	//@Bean, không cần @Bean ở lớp này, bởi vì ta không @Autowired ở hàm này, hàm này sử dụng cho @Bean MongoTemplate ở dưới
	public MongoDbFactory mongoDbFactory() throws UnknownHostException{
		MongoClient mongoClient = new MongoClient("localhost",27017);			
		return new SimpleMongoDbFactory(mongoClient,"myCollection");		
	}
	
	// Dùng  MongoTemplate để thao tác như create,delete,update,read...
	
	
	// Container sẽ tạo sẵn bean MongoTemplate, có connect tới MongoDB, và chúng ta chỉ việc @Autowired để sử dụng
	@Bean
	public MongoTemplate mongoTemplate() throws UnknownHostException{
		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
		return mongoTemplate;
	}

}
