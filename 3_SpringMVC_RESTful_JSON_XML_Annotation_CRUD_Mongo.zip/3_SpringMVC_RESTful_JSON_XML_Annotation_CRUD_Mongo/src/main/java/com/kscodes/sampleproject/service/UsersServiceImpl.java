package com.kscodes.sampleproject.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kscodes.sampleproject.model.Users;

@Service("userService")
@Transactional
public class UsersServiceImpl implements UserService{

	
	//Database at here 
		private static List<Users> populateUsers(){
			List<Users> users = new ArrayList<Users>();
			users.add(new Users(1,"Nguyen Viet A",20,6000));
			users.add(new Users(2,"Nguyen Viet B",21,7000));
			users.add(new Users(3,"Nguyen Viet C",22,8000));
			users.add(new Users(4,"Nguyen Viet D",23,9000));
			return users;
			
		}
		
	@Override
	public Users findById(long id) {
		for(Users user:populateUsers()){
			if(user.getId()==id)
			{
				return user;
			}
		}
		return null;
	}

	@Override
	public Users findByName(String name) {
		for(Users user:populateUsers()){
			if(user.getName()==name){
				return user;
			}
		}
		return null;
	}

	@Override
	public void saveUsers(Users users) {
		populateUsers().add(users);
		
	}

	//-----------get Indexof by Id ---------------------
	public int getIndexById(long id){
		for(int i=0; i<populateUsers().size();i++){
			Users user = populateUsers().get(i);
			if(user.getId()==id)
				return i;
		}
		return -1;
	}
	@Override
	public void updateUsers(Users users) {	
		int index = getIndexById(users.getId());				
		System.out.println("index cua user:" +index);
		populateUsers().set(index, users);
		
	}

	// delete User
	@Override
	public void deleteUsersById(long id) {
		for(Iterator<Users> iterator = populateUsers().iterator(); iterator.hasNext();){
			Users users = iterator.next();
			if(users.getId() == id){
				iterator.remove();
			}
		}
		
	}

	@Override
	public void deleteAllUsers() {
		// TODO Auto-generated method stub
		populateUsers().clear();
		
	}

	@Override
	public boolean isUsersExist(Users users) {
		// TODO Auto-generated method stub
		return findByName(users.getName())!=null;
	}

	@Override
	public List<Users> findAllUsers() {
		// TODO Auto-generated method stub
		return populateUsers();
	}
	

}
