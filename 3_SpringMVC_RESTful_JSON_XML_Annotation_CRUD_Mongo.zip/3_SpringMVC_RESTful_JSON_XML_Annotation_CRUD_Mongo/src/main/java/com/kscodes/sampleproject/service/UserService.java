package com.kscodes.sampleproject.service;

import java.util.List;

import com.kscodes.sampleproject.model.Users;

public interface UserService {
	
	Users findById(long id);
	Users findByName(String name);
	void saveUsers(Users users);
	void updateUsers(Users users);
	void deleteUsersById(long id);
	void deleteAllUsers();
	boolean isUsersExist(Users users);
	List<Users> findAllUsers();

}
