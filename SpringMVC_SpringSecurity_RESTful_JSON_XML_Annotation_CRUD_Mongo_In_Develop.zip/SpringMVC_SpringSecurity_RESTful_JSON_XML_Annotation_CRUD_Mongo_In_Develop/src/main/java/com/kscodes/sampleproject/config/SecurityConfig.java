package com.kscodes.sampleproject.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

import com.kscodes.sampleproject.service.MyUserDetailsService;

@Configuration      // create bean for this class
@EnableWebSecurity // enable web security 
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	public SecurityConfig(){
		super();
	}
	
	@Autowired
	private RestAuthenticationEntryPoint restAuthenticationEntryPoint;

	@Autowired
	private RestAuthenticationSuccessHandler restAuthenticationSuccessHandler;
	
	
	
    @Autowired
 	private MyUserDetailsService myUserDetailsSerivce;
	
//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
//		auth.userDetailsService(myUserDetailsSerivce);
//	}
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
    	auth.inMemoryAuthentication()
    	    .withUser("admin").password("admin").roles("USER","ADMIN")
   	        .and()
    	    .withUser("user").password("user").roles("USER");
    }
	
	protected void config(HttpSecurity http) throws Exception{
		
		 http
	      .httpBasic()
	      .and()
	      .authorizeRequests()
	      .antMatchers(HttpMethod.DELETE).hasRole("ADMIN")
	      .antMatchers(HttpMethod.GET).hasAnyRole("USER","ADMIN")
	      .antMatchers(HttpMethod.PUT).hasAnyRole("USER","ADMIN")
	      .antMatchers(HttpMethod.POST).hasAnyRole("USER","ADMIN")
	      .and()
	      .requiresChannel()
	      .antMatchers("/").requiresSecure()
	      .and()
	      .csrf().disable();
	}
	

	@Bean
    public RestAuthenticationSuccessHandler restAuthenticationSuccessHandler() {
        return new RestAuthenticationSuccessHandler();
    }
	
	@Bean
	public SimpleUrlAuthenticationFailureHandler myFailureHandler(){
		return  new SimpleUrlAuthenticationFailureHandler();
	}
}
