package com.kscodes.sampleproject.service;

import java.util.List;

import com.kscodes.sampleproject.model.Authorities;

public interface AuthoritiesService {
	Authorities findById(String id);
	void saveAuthorities(Authorities authorities);
	void updateAuthorities(Authorities authorities);
	void deleteAuthoritiessById(String id);
	void deleteAllAuthorities();
	boolean isAuthoritiesExist(Authorities authorities);
	List<Authorities> findAllAuthorities();

}
