package com.kscodes.sampleproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.kscodes.sampleproject.model.Authorities;
import com.kscodes.sampleproject.model.Users;

@Configuration
public class AuthoritiesServiceMongoImpl implements AuthoritiesService{

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Authorities findById(String id) {	
		return mongoTemplate.findById(id, Authorities.class);
	}

// ------------- create Authorities ---------------------
//  Nếu chưa có collection, Mongo tự tạo collection với tên là Users
	@Override
	public void saveAuthorities(Authorities authorities) {
		mongoTemplate.save(authorities);
		
	}

	@Override
	public void updateAuthorities(Authorities authorities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAuthoritiessById(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllAuthorities() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isAuthoritiesExist(Authorities authorities) {
		Authorities authority = findById(authorities.getUsername());
		if(authority==null){
			return false;
		}
		return true;
	}

	@Override
	public List<Authorities> findAllAuthorities() {		
		return mongoTemplate.findAll(Authorities.class);
	}
}
