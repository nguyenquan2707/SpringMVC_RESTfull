package com.kscodes.sampleproject.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Authorities")
public class Authorities {
	
	// fields
	@Id
	private String username;
	private String password;
	private int role;
	
	// constructors
	public Authorities(){
		super();
		
	}
	
	public Authorities(String username, String password, int role){
		this.username = username;
		this.password = password;
		this.role = role;
	}
	
	// getter and setter
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}

}
