package com.kscodes.sampleproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kscodes.sampleproject.model.Authorities;
import com.kscodes.sampleproject.service.AuthoritiesServiceMongoImpl;
import com.kscodes.sampleproject.service.UserServiceMongoImpl;

@RestController
public class AuthoritiesRestController {
	
	
	//Service will do all data retrieval/manipulation work
	@Autowired
	AuthoritiesServiceMongoImpl authoritiesServiceMongoImpl;
	
	//-------------- Retrieve all Authorities -----------------------
	@RequestMapping(value = "/authorities/", method = RequestMethod.GET)
	public ResponseEntity<List<Authorities>> getListAuthorities(){
		List<Authorities> listAuthorities = authoritiesServiceMongoImpl.findAllAuthorities();
		if(listAuthorities.isEmpty()){
			System.out.println("No Authorities List");
			return new ResponseEntity<List<Authorities>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Authorities>>(listAuthorities,HttpStatus.OK);
		
	}
	
	//--------------Retrieve one Authorities
	@RequestMapping(value = "/authority/{id}", method = RequestMethod.GET)
	public ResponseEntity<Authorities> getAuthorities(@PathVariable String id){
		System.out.println("Id vua nhan la: "+id);
		Authorities authority = authoritiesServiceMongoImpl.findById(id);
		if(authority==null){
			System.out.println("No Authority with this "+id);
			return new ResponseEntity<Authorities>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Authorities>(authority,HttpStatus.OK);
	}
	
	
	//---------------- Create Authorities ----------------
	@RequestMapping(value = "/authorities/", method = RequestMethod.POST)
	public ResponseEntity<Void> createAuthorities(@RequestBody Authorities authorities){
		System.out.println("We will create a user with role: "+authorities.getRole());
		if(authoritiesServiceMongoImpl.isAuthoritiesExist(authorities)){
			System.out.println("User da ton tai: ");
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}else{
			authoritiesServiceMongoImpl.saveAuthorities(authorities);
			return new ResponseEntity<Void>(HttpStatus.CREATED);
		}	
	}
	

}
