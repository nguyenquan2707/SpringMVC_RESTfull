package com.kscodes.sampleproject.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/* This will called once the request is authenticated,if it is not, the request will be 
 * redirected to authenticate entry point.
 * */

@Component
public class RestAuthenticationSuccessHandler extends SimpleUrlAuthenticationSuccessHandler{
//	save request
	private RequestCache requestCache =new HttpSessionRequestCache();
	
	@Override
	public void onAuthenticationSuccess(final HttpServletRequest request,
			final HttpServletResponse response,final Authentication authentication){
		final SavedRequest savedRequest = requestCache.getRequest(request, response);
		
		if(request == null){
			clearAuthenticationAttributes(request);
			return;
		}
		final String targetUrlParameter = getTargetUrlParameter();
		if(isAlwaysUseDefaultTargetUrl()
				||(targetUrlParameter!=null && StringUtils.hasText(
						request.getParameter(targetUrlParameter)))){
							requestCache.removeRequest(request, response);
							clearAuthenticationAttributes(request);
							return;
						}
		clearAuthenticationAttributes(request);
	}
	
	

}
