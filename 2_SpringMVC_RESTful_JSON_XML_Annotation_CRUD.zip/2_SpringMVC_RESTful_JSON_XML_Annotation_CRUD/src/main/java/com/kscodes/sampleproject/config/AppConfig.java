package com.kscodes.sampleproject.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@EnableWebMvc  // replace dispatcher-servlet
@Configuration // class can be used by the Spring IoC container as a source of bean definitions
@ComponentScan({ "com.kscodes.sampleproject.*" })  // search lop Controller
public class AppConfig {
	
	
	//ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
	//MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
	
	 // @Bean annotation tells Spring that a method annotated with @Bean will return an Object that
	      // should be registed as a bean in the Spring application context.
	/*
	@Bean
	public InternalResourceViewResolver viewResolver() {
		
		InternalResourceViewResolver viewResolver
		                             = new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/jsp/");// nhu khai bao trong dispatcher-servlet.xml
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;// as @Bean 
		
	}
	*/
}
