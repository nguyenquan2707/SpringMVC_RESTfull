package com.kscodes.sampleproject.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kscodes.sampleproject.model.Users;
import com.kscodes.sampleproject.service.UserService;

@RestController
public class MainRestController {
	
	//Service will do all data retrieval/manipulation work
	@Autowired
	UserService userService;
	
	//--------------   Retrieve all Users -----------------------
	
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public ResponseEntity<List<Users>> listAllUsers() {
		List<Users> listUsers = userService.findAllUsers();
		if(listUsers.isEmpty()){
			return new ResponseEntity<List<Users>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Users>>(listUsers,HttpStatus.OK);
		
	}
	
	
	//---------------- Retrieve one User --------------------------
	
	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public ResponseEntity<Users> getUser(@PathVariable long id){
		System.out.println("Id vua nhan la: "+id);
		
		Users user = userService.findById(id);
		if(user!=null){
			System.out.println("Tim thay User: ");
			return new ResponseEntity<Users>(user,HttpStatus.OK);
		}else{
			System.out.println("Not found user" );
		    return null;
		}
		
	}
	
	//----------------Create a new User -------------------------------
	@RequestMapping(value = "/users/", method = RequestMethod.POST)
	public ResponseEntity<Void> createUser(@RequestBody Users users){
		
		System.out.println("We will create User with name is: "+ users.getName());
		if(userService.isUsersExist(users)){
			System.out.println("User da ton tai: ");
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
			userService.saveUsers(users);
			//HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<Void>(HttpStatus.CREATED)	;				
	}
	
	
	//----------------update User-------------------------------------

		@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
		public ResponseEntity<Users> updateUser(@PathVariable("id") long id,@RequestBody Users users){
			
			Users user = userService.findById(id);		
			
			if(user==null){
				System.out.println("Khong tim thay User voi Id ls: "+id);
				return new ResponseEntity<Users>(HttpStatus.NOT_FOUND);
			}			
			
			user.setName(users.getName());
			user.setAge(users.getAge());
			user.setSalary(users.getSalary());
			userService.updateUsers(user);
			
			return new ResponseEntity<Users>(user,HttpStatus.OK);
			
		}
		
//------------------- delete User ------------------------------------------
		@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
		public ResponseEntity<Users> deleteUser(@PathVariable("id") long id){
			Users user = userService.findById(id);
			if(user==null){
				System.out.println("Khong ton tai user voi id: "+id);
				return new ResponseEntity<Users>(HttpStatus.NOT_FOUND);
			}
			
			userService.deleteUsersById(id);
			System.out.println("User da bi delete");
			return new ResponseEntity<Users>(user,HttpStatus.OK);
			
		}
		
//--------------------delete All User ----------------------------------------
		
		@RequestMapping(value = "/deletes/", method = RequestMethod.DELETE)
		public ResponseEntity<String> deleteAllUsers(){
			
			int count = userService.findAllUsers().size();
			if(count == 0){
				System.out.println("Khong co Users de xoa");
				return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			}
			userService.deleteAllUsers();
			return new ResponseEntity<String>("All Users da deletes thanh cong",HttpStatus.OK);
		}
	

}
