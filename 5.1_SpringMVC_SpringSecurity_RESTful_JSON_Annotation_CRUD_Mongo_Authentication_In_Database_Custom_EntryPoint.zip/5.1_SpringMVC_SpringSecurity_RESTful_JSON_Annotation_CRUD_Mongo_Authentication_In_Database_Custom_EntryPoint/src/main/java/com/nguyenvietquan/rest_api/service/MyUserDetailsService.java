package com.nguyenvietquan.rest_api.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.nguyenvietquan.rest_api.model.Authorities;


@Component
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	
	public List<GrantedAuthority>  getAuthorities(Integer role){
		List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>();
		
		if(role.intValue() == 1){
			authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
			authList.add(new SimpleGrantedAuthority("ROLE_USER"));
		}else if(role.intValue() == 2){
			authList.add(new SimpleGrantedAuthority("ROLE_USER"));
		}else if(role.intValue() == 0){
			authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
			authList.add(new SimpleGrantedAuthority("ROLE_ROOT"));
			authList.add(new SimpleGrantedAuthority("ROLE_USER"));
		}
		System.out.println(authList);
		return authList;
		
	}
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("DDDDDDDFDFDFDFDFDFDF");
		
		Authorities authorities;
		User userDetails = null;
		try{
			authorities = mongoTemplate.findById(username, Authorities.class);
			userDetails = new User(authorities.getUsername(),authorities.getPassword(),
					true,true,true,true,getAuthorities(authorities.getRole()));
		return userDetails;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//dung ham Constructor cua lop User, de tra ve thong tin trong Mongo
		return userDetails;
	}

}

