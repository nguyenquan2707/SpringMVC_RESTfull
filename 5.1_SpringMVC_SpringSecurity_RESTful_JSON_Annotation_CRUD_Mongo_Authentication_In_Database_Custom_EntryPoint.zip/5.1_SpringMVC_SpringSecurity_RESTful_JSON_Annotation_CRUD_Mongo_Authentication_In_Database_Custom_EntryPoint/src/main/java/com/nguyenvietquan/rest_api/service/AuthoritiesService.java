package com.nguyenvietquan.rest_api.service;

import java.util.List;

import com.nguyenvietquan.rest_api.model.Authorities;

public interface AuthoritiesService {
	Authorities findById(String id);
	void saveAuthority(Authorities authority);
	void updateAuthority(Authorities authority);
	void deleteAuthorityById(String id);
	void deleteAllAuthorities();
	boolean isUsersExist(Authorities authority);
	List<Authorities> findAllAuthorities();

}
