package com.nguyenvietquan.rest_api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nguyenvietquan.rest_api.model.Authorities;
import com.nguyenvietquan.rest_api.model.Users;

@Configuration
@Transactional
public class AuthoritiesServiceMongoImpl implements AuthoritiesService {
	
	@Autowired
	MongoTemplate mongoTemplate;
//--------------- find by username ----------------------------
	@Override
	public Authorities findById(String id) {
		return mongoTemplate.findById(id, Authorities.class);
	}

//-------------- save 1 account vào mongo ----------------------
//  Nếu chưa có collection, Mongo tự tạo collection với tên là Users
	@Override
	public void saveAuthority(Authorities authority) {
		mongoTemplate.save(authority);
		
	}

//-------------- update password 1 account ---------------------
	@Override
	public void updateAuthority(Authorities authority) {
		Query searchAuthorityQuery = new Query(Criteria.where("id").is(authority.getUsername()));
		Authorities savedAuthorities = mongoTemplate.findOne(searchAuthorityQuery, Authorities.class);
		savedAuthorities.setPassword(authority.getPassword());
		mongoTemplate.save(savedAuthorities);
		System.out.println("Password have been updated sussesfully");
		
	}

// ------------- delete 1 account ----------------------------------
	@Override
	public void deleteAuthorityById(String id) {
		//Query searchUserQuery = new Query(Criteria.where("id").is(id));
		//Users savedUser = mongoTemplate.findOne(searchUserQuery, Users.class);
		//System.out.println("We will this user: "+savedUser);
		//mongoTemplate.remove(savedUser);		
		mongoTemplate.remove(new Query(Criteria.where("username").is(id)), Authorities.class);
		
	}

//--------------- delete all of the account -------------------------
	@Override
	public void deleteAllAuthorities() {
		mongoTemplate.remove(new Query(), "Authorities");
		
	}

//---------------- check account exist -------------------------------
	@Override
	public boolean isUsersExist(Authorities authority) {
		Authorities savedAuthority = findById(authority.getUsername());
		if(savedAuthority==null){
		return false;
		}
		return true;
	}

// ----------------- find all the account ---------------------------
	@Override
	public List<Authorities> findAllAuthorities() {
		return mongoTemplate.findAll(Authorities.class);
	}

}
