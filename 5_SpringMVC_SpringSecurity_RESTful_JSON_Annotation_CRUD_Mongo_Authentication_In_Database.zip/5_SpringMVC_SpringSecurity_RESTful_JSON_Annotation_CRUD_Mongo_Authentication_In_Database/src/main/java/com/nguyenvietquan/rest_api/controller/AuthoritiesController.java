package com.nguyenvietquan.rest_api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nguyenvietquan.rest_api.model.Authorities;
import com.nguyenvietquan.rest_api.service.AuthoritiesService;

@RestController
public class AuthoritiesController {
	
	@Autowired
	AuthoritiesService authoritiesService;
	
// ----------- Retrieve all account --------------------
	@RequestMapping(value = "/authorities/", method = RequestMethod.GET)
	public ResponseEntity<List<Authorities>> getALlAccount(){
		List<Authorities> listAccount = authoritiesService.findAllAuthorities();
		if(listAccount==null){
			System.out.println("Không có Account ");
			return new ResponseEntity<List<Authorities>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Authorities>>(listAccount,HttpStatus.OK);
	}
	
// ---------- Retrieve one account ------------------------
	@RequestMapping(value = "/authority/{id}", method = RequestMethod.GET)
	public ResponseEntity<Authorities> getOneAccount(@PathVariable String id){
		System.out.println("User là "+id);
		Authorities authorities = authoritiesService.findById(id);
		if(authorities == null){
			System.out.println("Không tìm thấy Account");
			return new ResponseEntity<Authorities>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Authorities>(authorities,HttpStatus.OK);
		
	}
	
	
//------------- Create a account ---------------------------
	@RequestMapping(value ="/authorities/", method = RequestMethod.POST)
	public ResponseEntity<Void> createAccount(@RequestBody Authorities authority){
		System.out.println("We will create one Account with username is: "+ authority.getUsername());
		if(authoritiesService.isUsersExist(authority)){
			System.out.println("Account da ton tai: ");
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		   authoritiesService.saveAuthority(authority);
		   return new ResponseEntity<Void>(HttpStatus.CREATED);
		
	}
	
// -------------- update password ------------------------------
	@RequestMapping(value = "/authority/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Authorities> updateAccount(@PathVariable String id,@RequestBody Authorities authority){
		System.out.println("We will update Account with usename is: "+authority.getUsername());
		Authorities savedAuthority =authoritiesService.findById(id);
		if(savedAuthority==null){
			System.out.println("Không tìm thấy account "+id);
			return new ResponseEntity<Authorities>(HttpStatus.NOT_FOUND);
		}
		savedAuthority.setPassword(authority.getPassword());
		authoritiesService.saveAuthority(savedAuthority);
		return new ResponseEntity<Authorities>(savedAuthority,HttpStatus.OK);
	}
	
// --------------- delete one account ------------------------------
	@RequestMapping( value = "/authority/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Authorities> deleteAccount(@PathVariable String id){
		Authorities authority = authoritiesService.findById(id);
		if(authority==null){
			System.out.println("Không tồn tại Account with username: "+id);
			return new ResponseEntity<Authorities>(HttpStatus.NOT_FOUND);
		}
		authoritiesService.deleteAuthorityById(id);
		System.out.println("Account "+id+" have been deleted successfully");
		return new ResponseEntity<Authorities>(authority,HttpStatus.OK);
	}
	
// -------------- delete all account ---------------------------------
	@RequestMapping( value ="/authorities/", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteAllAccount(){
		List<Authorities> count = authoritiesService.findAllAuthorities();
		if(count.isEmpty()){
			return new ResponseEntity<String>("No Account to delete",HttpStatus.NO_CONTENT);
		}
		String str="All of account have been deleted";
		authoritiesService.deleteAllAuthorities();
		return new ResponseEntity<String>(str,HttpStatus.OK);
	}
		

}
